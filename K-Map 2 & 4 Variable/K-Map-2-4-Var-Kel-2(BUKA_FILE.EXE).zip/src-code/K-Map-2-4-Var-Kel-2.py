#import tabulate untk membuat tabel 
from tabulate import tabulate

def inp2_k_map(mt, nip):
    for i in range(50):
        print("-", end='')
    print()
    prnt = input(
        "Masukkan Variabel dengan spasi tunggal! (eg:A B) : ").split(" ")
    for i in range(len(mt)):
        mt[i] = '0b'+bin(mt[i])[2:].lstrip('0')
    op = ''
    ans = [[0, 0], [0, 0]]
    ansmx = [[0, 0], [0,0]]
    flag = 0
    temp = []
    for i in range(2):
        for j in range(2):
            p = '0b'+(bin(i)[2:]+bin(j)[2:]).lstrip('0')
            if p in mt:
                ans[i][j] = 1
    for i in range(50):
        print("-", end='')
    print()
    print("Peta K-Map : ")


    if nip == 1:
        # #test logic :
        # for each in ans:
        #     print(*each)

        #tabel-SOP
        myans = [
            ["", prnt[1]],
            [prnt[0], ans[0][0],ans[0][1]],
            ["", ans[1][0],ans[1][1]]
        ]
        print(tabulate(myans, tablefmt="grid"))
            
            
    if nip == 2:
        for i in range(2):
            for j in range(2):
                if ans[i][j] == 1:
                    ansmx[i][j] = 0
                else:
                    ansmx[i][j] = 1
        # #tesr logic
        # for each in ansmx:
        #     print(*each)

        #tabel-POS
        myansmx = [
            ["", prnt[1]],
            [prnt[0], ansmx[0][0],ansmx[0][1]],
            ["", ansmx[1][0],ansmx[1][1]]
        ]
        print(tabulate(myansmx, tablefmt="grid"))
    
            
    if ans == [[1, 1], [1, 1]]:
        flag = 1
        op = '1'

    if flag == 0:
        for i in range(2):
            if ans[i] == [1, 1]:
                if nip == 1:
                    op = 'A ' if i == 1 else "A' "
                elif nip == 2:
                    op = "(A') " if i == 1 else "(A) "
                temp.extend([(i, 0), (i, 1)])

    if flag == 0:
        if ans[0][0] == 1 and ans[1][0] == 1:
            if nip == 1:
                op = op+"B' "
            elif nip == 2:
                op = op+"(B) "
            temp.extend([(0, 0), (1, 0)])
        elif ans[0][1] == 1 and ans[1][1] == 1:
            if nip == 1:
                op = op+"B "
            elif nip == 2:
                op = op+"(B') "
            temp.extend([(0, 1), (1, 1)])
    if nip == 1:
        vr = ["A'B' ", "A'B ", "AB' ", "AB "]
    elif nip == 2:
        vr = ["(A+B) ", "(A+B') ", "(A'+B) ", "(A'+B') "]

    if flag == 0:
        for i in range(2):
            for j in range(2):
                if ans[i][j] == 1 and (i, j) not in temp:
                    op = op+vr[int('0b'+bin(i)[2:]+bin(j)[2:], 2)]
    op = op.rstrip(" ")
    if nip == 1:
        op = op.replace(" ", "+")
    op = op.replace("A", prnt[0])
    op = op.replace("B", prnt[1])
    
    for i in range(50):
        print("*", end='')
    print()
    print("Persamaan yang disederhanakan adalah :", op)
    for i in range(50):
        print("*", end='')
    print()

# K_Map for 4 inputs.


def inp4_k_map(mt, nip):
    import copy
    for _ in range(50):
        print("-", end='')
    print()
    pr_v = input("Masukkan Variabel dengan spasi tunggal! (eg:A B C D) : ").split(" ")
    an = []
    anmx = []
    (tmp, flag) = (0, 0)
    op = ''
    for i in range(4):
        an.append([0]*4)
        anmx.append([0]*4)

    for i in range(4):
        for j in range(4):
            if i < 2:
                bi = '0'+bin(i)[2:]
            else:
                bi = bin(i)[2:]
            if j < 2:
                bj = '0'+bin(j)[2:]
            else:
                bj = bin(j)[2:]
            p = int('0b'+bi+bj, 2)
            if p in mt:
                an[i][j] = 1
    for i in range(4):
        (an[i][2], an[i][3]) = (an[i][3], an[i][2])
    for i in range(4):
        (an[2][i], an[3][i]) = (an[3][i], an[2][i])

    for _ in range(50):
        print("-", end='')
    print()
    print("Peta K-Map : : ")
    if nip == 1:
        # #logic test:
        # for each in an:
        #     print(*each)

        # #tabel SOP
        myan = [
    ["", pr_v[2]+pr_v[3]],
    [pr_v[0]+pr_v[1], an[0][0],an[0][1],an[0][2],an[0][3]],
    ["", an[1][0],an[1][1],an[1][2],an[1][3]],
    ["", an[2][0],an[2][1],an[2][2],an[2][3]],
    ["", an[3][0],an[3][1],an[3][2],an[3][3]],
]

        print(tabulate(myan, tablefmt="grid"))


    if nip == 2:
        for i in range(4):
            for j in range(4):
                if an[i][j] == 1:
                    anmx[i][j] = 0
                else:
                    anmx[i][j] = 1
        
        # #logic test :
        # for each in anmx:
        #     print(*each)

        # #tabel POS
        myanmx = [
    ["", pr_v[2]+pr_v[3]],
    [pr_v[0]+pr_v[1], anmx[0][0],anmx[0][1],anmx[0][2],anmx[0][3]],
    ["", anmx[1][0],anmx[1][1],anmx[1][2],anmx[1][3]],
    ["", anmx[2][0],anmx[2][1],anmx[2][2],anmx[2][3]],
    ["", anmx[3][0],anmx[3][1],anmx[3][2],anmx[3][3]],
]

        print(tabulate(myanmx, tablefmt="grid"))

    octa = []
    qrd = []
    qrd_ref = []
    qrd_rep = []
    dul = []
    sngl = []
    if nip == 1:
        octa_val = [["C' ", "D ", "C ", "D' "], [
            "A' ", "B ", "A ", "B' "]]  # 0 for vert and 1 for horz
        qrd_val = [["C'D' ", "C'D ", "CD ", "CD' "], [
            "A'B' ", "A'B ", "AB ", "AB' "]]  # 0 for vert and 1 for horz
        qrd_val_4 = [["A'C' ", "A'D ", "A'C ", "A'D' "], ["BC' ", "BD ", "BC ", "BD' "], [
            "AC' ", "AD ", "AC ", "AD' "], ["B'C' ", "B'D ", "B'C ", "B'D' "]]
        dul_vert = [["A'C'D' ", "A'C'D ", "A'CD ", "A'CD' "], ["BC'D' ", "BC'D ", "BCD ", "BCD' "], [
            "AC'D' ", "AC'D ", "ACD ", "ACD' "], ["B'C'D' ", "B'C'D ", "B'CD ", "B'CD' "]]
        dul_horz = [["A'B'C' ", "A'B'D ", "A'B'C ", "A'B'D' "], ["A'BC' ", "A'BD ", "A'BC ", "A'BD' "], [
            "ABC' ", "ABD ", "ABC ", "ABD' "], ["AB'C' ", "AB'D ", "AB'C ", "AB'D' "]]
        sngl_val = [["A'B'C'D' ", "A'B'C'D ", "A'B'CD ", "A'B'CD' "], ["A'BC'D' ", "A'BC'D ", "A'BCD ", "A'BCD' "], [
            "ABC'D' ", "ABC'D ", "ABCD ", "ABCD' "], ["AB'C'D' ", "AB'C'D ", "AB'CD ", "AB'CD' "]]
    elif nip == 2:
        octa_val = [["(C) ", "(D') ", "(C') ", "(D) "], [
            "(A) ", "(B') ", "(A') ", "(B) "]]  # 0 for vert and 1 for horz
        qrd_val = [["(C+D) ", "(C+D') ", "(C'+D') ", "(C'+D) "], ["(A+B) ",
                                                                  "(A+B') ", "(A'+B') ", "(A'+B) "]]  # 0 for vert and 1 for horz
        qrd_val_4 = [["(A+C) ", "(A+D') ", "(A+C') ", "(A+D) "], ["(B'+C) ", "(B'+D') ", "(B'+C') ", "(B'+D) "],
                     ["(A'+C) ", "(A'+D') ", "(A'+C') ", "(A'+D) "], ["(B+C) ", "(B+D') ", "(B+C') ", "(B+D) "]]
        dul_vert = [["(A+C+D) ", "(A+C+D') ", "(A+C'+D') ", "(A+C'+D) "], ["(B'+C+D) ", "(B'+C+D') ", "(B'+C'+D') ", "(B'+C'+D) "],
                    ["(A'+C+D) ", "(A'+C+D') ", "(A'+C'+D') ", "(A'+C'+D) "], ["(B+C+D) ", "(B+C+D') ", "(B+C'+D') ", "(B+C'+D) "]]
        dul_horz = [["(A+B+C) ", "(A+B+D') ", "(A+B+C') ", "(A+B+D) "], ["(A+B'+C) ", "(A+B'+D') ", "(A+B'+C') ", "(A+B'+D) "],
                    ["(A'+B'+C) ", "(A'+B'+D') ", "(A'+B'+C') ", "(A'+B'+D) "], ["(A'+B+C) ", "(A'+B+D') ", "(A'+B+C') ", "(A'+B+D) "]]
        sngl_val = [["(A+B+C+D) ", "(A+B+C+D') ", "(A+B+C'+D') ", "(A+B+C'+D) "], ["(A+B'+C+D) ", "(A+B'+C+D') ", "(A+B'+C'+D') ", "(A+B'+C'+D) "],
                    ["(A'+B'+C+D) ", "(A'+B'+C+D') ", "(A'+B'+C'+D') ", "(A'+B'+C'+D) "], ["(A'+B+C+D) ", "(A'+B+C+D') ", "(A'+B+C'+D') ", "(A'+B+C'+D) "]]

    if an == [[1]*4, [1]*4, [1]*4, [1]*4]:
        op = '1'
    else:
        for i in range(-1, 3):
            if an[i][0] == 1 and an[i][1] == 1 and an[i][2] == 1 and an[i][-1] == 1 and an[i+1][0] == 1 and an[i+1][1] == 1 and an[i+1][2] == 1 and an[i+1][-1] == 1:
                op = op+octa_val[1][i]
                octa.append([(i, 0), (i, 1), (i, 2), (i, -1)])
                if i < 2:
                    octa.append([(i+1, 0), (i+1, 1), (i+1, 2), (i+1, -1)])
                else:
                    octa.append([(-1, 0), (-1, 1), (-1, 2), (-1, -1)])
                if i < 2:
                    octa.append([(i, 0), (i+1, 0), (i, 1), (i+1, 1)])
                    octa.append([(i, 1), (i+1, 1), (i, 2), (i+1, 2)])
                    octa.append([(i, 2), (i+1, 2), (i, -1), (i+1, -1)])
                    octa.append([(i, -1), (i+1, -1), (i, 0), (i+1, 0)])
                else:
                    octa.append([(i, 0), (-1, 0), (i, 1), (-1, 1)])
                    octa.append([(i, 1), (-1, 1), (i, 2), (-1, 2)])
                    octa.append([(i, 2), (-1, 2), (i, -1), (-1, -1)])
                    octa.append([(i, -1), (-1, -1), (i, 0), (-1, 0)])

        for i in range(-1, 3):
            if an[0][i] == 1 and an[1][i] == 1 and an[2][i] == 1 and an[-1][i] == 1 and an[0][i+1] == 1 and an[1][i+1] == 1 and an[2][i+1] == 1 and an[-1][i+1] == 1:
                op = op+octa_val[0][i]
                octa.append([(0, i), (1, i), (2, i), (-1, i)])
                if i < 2:
                    octa.append([(0, i+1), (1, i+1), (2, i+1), (-1, i+1)])
                else:
                    octa.append([(0, -1), (1, -1), (2, -1), (-1, -1)])
                if i < 2:
                    octa.append([(0, i), (1, i), (0, i+1), (1, i+1)])
                    octa.append([(1, i), (2, i), (1, i+1), (2, i+1)])
                    octa.append([(2, i), (-1, i), (2, i+1), (-1, i+1)])
                    octa.append([(-1, i), (0, i), (-1, i+1), (0, i+1)])
                else:
                    octa.append([(0, i), (1, i), (0, -1), (1, -1)])
                    octa.append([(1, i), (2, i), (1, -1), (2, -1)])
                    octa.append([(2, i), (-1, i), (2, -1), (-1, -1)])
                    octa.append([(-1, i), (0, i), (-1, -1), (0, -1)])

        for i in range(-1, 3):
            if an[i][0] == 1 and an[i][1] == 1 and an[i][2] == 1 and an[i][-1] == 1:
                qrd_ref.append([(i, 0), (i, 1), (i, 2), (i, -1)])
            if an[0][i] == 1 and an[1][i] == 1 and an[2][i] == 1 and an[-1][i] == 1:
                qrd_ref.append([(0, i), (1, i), (2, i), (-1, i)])

        for i in range(-1, 3):
            for j in range(-1, 3):
                if an[i][j] == 1 and an[i][j+1] == 1 and an[i+1][j] == 1 and an[i+1][j+1] == 1:
                    if i == 2 and j == 2:
                        temp = [(i, j), (-1, j), (i, -1), (-1, -1)]
                    elif i == 2 and j < 2:
                        temp = [(i, j), (-1, j), (i, j+1), (-1, j+1)]
                    elif j == 2 and i < 2:
                        temp = [(i, j), (i+1, j), (i, -1), (i+1, -1)]
                    else:
                        temp = [(i, j), (i+1, j), (i, j+1), (i+1, j+1)]
                    qrd_ref.append(temp)

        for i in range(-1, 3):
            if an[i][0] == 1 and an[i][1] == 1 and an[i][2] == 1 and an[i][-1] == 1:
                if [(i, 0), (i, 1), (i, 2), (i, -1)] not in octa:
                    op = op+qrd_val[1][i]
                    qrd.append([(i, 0), (i, 1)])
                    qrd.append([(i, 1), (i, 2)])
                    qrd.append([(i, 2), (i, -1)])
                    qrd.append([(i, -1), (i, 0)])

        for i in range(-1, 3):
            if an[0][i] == 1 and an[1][i] == 1 and an[2][i] == 1 and an[-1][i] == 1:
                if [(0, i), (1, i), (2, i), (-1, i)] not in octa:
                    op = op+qrd_val[0][i]
                    qrd.append([(0, i), (1, i)])
                    qrd.append([(1, i), (2, i)])
                    qrd.append([(2, i), (-1, i)])
                    qrd.append([(-1, i), (0, i)])

        for i in range(-1, 3):
            for j in range(-1, 3):
                if an[i][j] == 1 and an[i][j+1] == 1 and an[i+1][j] == 1 and an[i+1][j+1] == 1:
                    if i == 2 and j == 2:
                        temp = [(i, j), (-1, j), (i, -1), (-1, -1)]
                    elif i == 2 and j < 2:
                        temp = [(i, j), (-1, j), (i, j+1), (-1, j+1)]
                    elif j == 2 and i < 2:
                        temp = [(i, j), (i+1, j), (i, -1), (i+1, -1)]
                    else:
                        temp = [(i, j), (i+1, j), (i, j+1), (i+1, j+1)]
                    if temp not in octa:
                        op = op+qrd_val_4[i][j]
                        if i < 2 and j < 2:
                            qrd.append([(i, j), (i, j+1)])
                            qrd.append([(i+1, j), (i+1, j+1)])
                            qrd.append([(i, j), (i+1, j)])
                            qrd.append([(i, j+1), (i+1, j+1)])
                        if j == 2 and i < 2:
                            qrd.append([(i, j), (i, -1)])
                            qrd.append([(i+1, j), (i+1, -1)])
                            qrd.append([(i, j), (i+1, j)])
                            qrd.append([(i, -1), (i+1, -1)])
                        if j < 2 and i == 2:
                            qrd.append([(i, j), (i, j+1)])
                            qrd.append([(-1, j), (-1, j+1)])
                            qrd.append([(i, j), (-1, j)])
                            qrd.append([(i, j+1), (-1, j+1)])
                        if i == 2 and j == 2:
                            qrd.append([(i, j), (i, -1)])
                            qrd.append([(-1, j), (-1, -1)])
                            qrd.append([(i, j), (-1, j)])
                            qrd.append([(i, -1), (-1, -1)])

        for i in range(-1, 3):
            for j in range(-1, 3):
                if an[i][j] == 1 and an[i][j+1] == 1:
                    if j == 2:
                        temp = [(i, j), (i, -1)]
                    else:
                        temp = [(i, j), (i, j+1)]
                    if temp not in qrd:
                        op = op+dul_horz[i][j]
                        if j == 2:
                            dul.append([(i, j), (i, -1)])
                        else:
                            dul.append([(i, j), (i, j+1)])
                if an[i][j] == 1 and an[i+1][j] == 1:
                    if i == 2:
                        temp = [(i, j), (-1, j)]
                    else:
                        temp = [(i, j), (i+1, j)]
                    if temp not in qrd:
                        op = op+dul_vert[i][j]
                        if i == 2:
                            dul.append([(i, j), (-1, j)])
                        else:
                            dul.append([(i, j), (i+1, j)])

        for each in octa:
            sngl.extend(each)
        for each in qrd:
            sngl.extend(each)
        for each in dul:
            sngl.extend(each)
        for i in range(-1, 3):
            for j in range(-1, 3):
                if an[i][j] == 1:
                    if (i, j) not in sngl:
                        op = op+sngl_val[i][j]

        op = op.strip()
        opl = op.split(" ")
        for i in range(len(opl)):
            opl[i] = opl[i]+" "

        dulref = copy.deepcopy(dul)

        for each in dul:
            (d1, d2) = (each[0], each[1])
            (cntd1, cntd2) = (0, 0)
            for each in dulref:
                if d1 in each:
                    cntd1 += 1
                if d2 in each:
                    cntd2 += 1
            for each in qrd_ref:
                if d1 in each:
                    cntd1 += 1
                if d2 in each:
                    cntd2 += 1
            if cntd1 > 1 and cntd2 > 1:
                try:
                    if d1[0] == d2[0]:
                        opl.remove(dul_horz[d1[0]][d1[1]])
                    if d1[1] == d2[1]:
                        opl.remove(dul_vert[d1[0]][d1[1]])
                    dulref.remove([(d1[0], d1[1]), (d2[0], d2[1])])
                except ValueError:
                    continue

        for each in qrd_ref:
            (d1, d2, d3, d4) = (each[0], each[1], each[2], each[3])
            (d1cnt, d2cnt, d3cnt, d4cnt) = (0, 0, 0, 0)
            for each1 in dul:
                if d1 in each1:
                    d1cnt += 1
                if d2 in each1:
                    d2cnt += 1
                if d3 in each1:
                    d3cnt += 1
                if d4 in each1:
                    d4cnt += 1
            for each2 in qrd_ref:
                if each != each2:
                    if d1 in each2:
                        d1cnt += 1
                    if d2 in each2:
                        d2cnt += 1
                    if d3 in each2:
                        d3cnt += 1
                    if d4 in each2:
                        d4cnt += 1
            if d1cnt > 0 and d2cnt > 0 and d3cnt > 0 and d4cnt > 0:
                try:
                    if d1[0] != d2[0] and d1[1] != d3[1]:
                        opl.remove(qrd_val_4[d1[0]][d1[1]])
                except ValueError:
                    continue

        for each in qrd_ref:
            (d1, d2, d3, d4) = (each[0], each[1], each[2], each[3])
            (d1cnt, d2cnt, d3cnt, d4cnt) = (0, 0, 0, 0)
            for each1 in qrd_ref:
                if each1 != each:
                    if d1 in each1:
                        d1cnt += 1
                    if d2 in each1:
                        d2cnt += 1
                    if d3 in each1:
                        d3cnt += 1
                    if d4 in each1:
                        d4cnt += 1
                if d1cnt > 0 and d2cnt > 0 and d3cnt > 0 and d4cnt > 0:
                    try:
                        if d1[0] == d2[0] == d3[0] == d4[0]:
                            opl.remove(qrd_val[1][d1[0]])
                        elif d1[1] == d2[1] == d3[1] == d4[1]:
                            opl.remove(qrd_val[0][d1[1]])
                    except ValueError:
                        continue

        op = ''.join(opl)
    for _ in range(50):
        print("*", end='')
    print()
    op = op.strip(" ")
    if nip == 1:
        op = op.replace(" ", " + ")
    op = op.replace("A", pr_v[0])
    op = op.replace("B", pr_v[1])
    op = op.replace("C", pr_v[2])
    op = op.replace("D", pr_v[3])
    print("Persamaan yang disederhanakan adalah :", op)

    for _ in range(50):
        print("*", end='')
    print()


# main
ask = 'y'
while ask == 'y':
    for _ in range(50):
        print("-", end='')
    print()
    print("\nKelompok 2")
    print("\n-------Aplikasi Karnaugh Map 2 & 4 Variabel-------\n")
    nfinp = int(input("Masukkan nomor input jumlah variabel(2,4) : "))
    mimastr = input(
        "Masukkan SOP(Minterm) / POS(Maxterm) (SOP/POS) : ").lower()
    if mimastr == 'pos':
        mima = 2
    elif mimastr == 'sop':
        mima = 1
    if mima == 1:
        mt = list(map(int, input("Masukkan Minterm : ").split()))
    else:
        mt = list(map(int, input("Masukkan Maxterm : ").split()))
    if nfinp == 2:
        inp2_k_map(mt, mima)
    elif nfinp == 4:
        inp4_k_map(mt, mima)
    else:
        print("Anda melakukan beberapa kesalahan, silakan periksa input anda!")
    ask = input("Masukkan 'y' untuk K-Map lain atau 'n' untuk keluar : ").lower()
    for i in range(25):
        print("--", end='')
    print()